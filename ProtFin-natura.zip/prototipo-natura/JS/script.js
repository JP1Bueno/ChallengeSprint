const alternadorChatbot = document.querySelector(".chatbot-toggler"); 
const btnFechar = document.querySelector(".close-btn");
const caixaDeChat = document.querySelector(".chatbox");
const entradaDeChat = document.querySelector(".chat-input textarea");
const btnEnviarChat = document.querySelector(".chat-input span");

let mensagemUsuario = null; // Variável para armazenar a mensagem do usuário
const alturaInicialEntrada = entradaDeChat.scrollHeight;

// Configuração da API
const CHAVE_API = "AIzaSyBUph6-TjicoaKAxdxX310N5_IaLbbEjR8"; // Sua chave de API aqui
const URL_API = `https://generativelanguage.googleapis.com/v1/models/gemini-pro:generateContent?key=${CHAVE_API}`;

const criarElementoChatLi = (mensagem, nomeClasse) => {
  // Cria um elemento <li> de chat com a mensagem e a classe passadas
  const chatLi = document.createElement("li");
  chatLi.classList.add("chat", `${nomeClasse}`);
  let conteudoChat = nomeClasse === "outgoing" ? `<p></p>` : `<span class="material-symbols-outlined">smart_toy</span><p></p>`;
  chatLi.innerHTML = conteudoChat;
  chatLi.querySelector("p").textContent = mensagem;
  return chatLi; // Retorna o elemento <li> do chat
};

const gerarResposta = async (elementoChat) => {
  const elementoMensagem = elementoChat.querySelector("p");

  // Define as propriedades e a mensagem para a requisição da API
  const opcoesRequisicao = {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [
        {
          role: "user",
          parts: [{ text: mensagemUsuario }],
        },
      ],
    }),
  };

  // Envia a requisição POST para a API, obtém a resposta e define o texto da resposta no parágrafo
  try {
    const resposta = await fetch(URL_API, opcoesRequisicao);
    const dados = await resposta.json();
    if (!resposta.ok) throw new Error(dados.error.message);

    // Obtém o texto da resposta da API e atualiza o elemento da mensagem
    elementoMensagem.textContent = dados.candidates[0].content.parts[0].text.replace(/\*\*(.*?)\*\*/g, "$1");
  } catch (erro) {
    // Trata erros
    elementoMensagem.classList.add("error");
    elementoMensagem.textContent = erro.message;
  } finally {
    caixaDeChat.scrollTo(0, caixaDeChat.scrollHeight);
  }
};

const lidarComChat = () => {
  mensagemUsuario = entradaDeChat.value.trim(); // Obtém a mensagem digitada pelo usuário e remove espaços em branco extras
  if (!mensagemUsuario) return;

  // Limpa o campo de entrada de texto e redefine sua altura para o valor inicial
  entradaDeChat.value = "";
  entradaDeChat.style.height = `${alturaInicialEntrada}px`;

  // Adiciona a mensagem do usuário à caixa de chat
  caixaDeChat.appendChild(criarElementoChatLi(mensagemUsuario, "outgoing"));
  caixaDeChat.scrollTo(0, caixaDeChat.scrollHeight);

  setTimeout(() => {
    // Exibe a mensagem "Pensando..." enquanto aguarda a resposta
    const chatLiEntrada = criarElementoChatLi("Pensando...", "incoming");
    caixaDeChat.appendChild(chatLiEntrada);
    caixaDeChat.scrollTo(0, caixaDeChat.scrollHeight);
    gerarResposta(chatLiEntrada);
  }, 600);
};

entradaDeChat.addEventListener("input", () => {
  // Ajusta a altura do campo de entrada de texto com base no seu conteúdo
  entradaDeChat.style.height = `${alturaInicialEntrada}px`;
  entradaDeChat.style.height = `${entradaDeChat.scrollHeight}px`;
});

entradaDeChat.addEventListener("keydown", (e) => {
  // Se a tecla Enter for pressionada sem Shift e a largura da janela for maior que 800px, lida com o chat
  if (e.key === "Enter" && !e.shiftKey && window.innerWidth > 800) {
    e.preventDefault();
    lidarComChat();
  }
});

btnEnviarChat.addEventListener("click", lidarComChat);
btnFechar.addEventListener("click", () => document.body.classList.remove("show-chatbot"));
alternadorChatbot.addEventListener("click", () => document.body.classList.toggle("show-chatbot"));
