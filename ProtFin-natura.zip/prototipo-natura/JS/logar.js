function logar() {
    var login = document.getElementById('login').value;
    var senha = document.getElementById('senha').value;

    alert('Sucesso');
    location.href = "home.html";
}

function sair() {
    // Redireciona para a página de login
    window.location.href = "login.html";
}
