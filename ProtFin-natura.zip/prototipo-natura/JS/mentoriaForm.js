document.getElementById('mentoriaForm').addEventListener('submit', function (e) {
    e.preventDefault();
    
    // Capturar os dados do formulário
    const mentor = document.getElementById('mentor').value;
    const date = document.getElementById('date').value;

    // Simular envio de agendamento para o backend
    if (mentor && date) {
        document.getElementById('statusAgendamento').textContent = 'Sessão de mentoria agendada com sucesso!';
        document.getElementById('statusAgendamento').style.color = 'green';
        
        // Limpar o formulário
        document.getElementById('mentoriaForm').reset();
    } else {
        document.getElementById('statusAgendamento').textContent = 'Erro ao agendar sessão. Por favor, tente novamente.';
        document.getElementById('statusAgendamento').style.color = 'red';
    }
});
