function mostrarFormularioEditar() {
    document.getElementById("form-editar").style.display = "block";
    document.getElementById("editarPerfil").style.display = "none"; // Esconde o botão de editar
}

function salvarPerfil() {
    const nome = document.getElementById("nome").value;
    const email = document.getElementById("email").value;
    const telefone = document.getElementById("telefone").value;

    // Aqui você pode adicionar lógica para salvar as informações
    // Por exemplo, enviar para um servidor via API

    // Atualiza as informações exibidas
    document.getElementById("nome-consultora").innerText = nome;
    document.getElementById("email-consultora").innerText = email;
    document.getElementById("telefone-consultora").innerText = telefone;

    // Esconde o formulário de edição
    document.getElementById("form-editar").style.display = "none";
    document.getElementById("editarPerfil").style.display = "block"; // Mostra o botão de editar novamente
}

function cancelarEdicao() {
    document.getElementById("form-editar").style.display = "none"; // Esconde o formulário de edição
    document.getElementById("editarPerfil").style.display = "block"; // Mostra o botão de editar novamente
}