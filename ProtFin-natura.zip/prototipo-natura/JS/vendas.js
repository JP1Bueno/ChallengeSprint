// vendas.js

// Dados fictícios para o gráfico
const salesData = [5, 10, 15, 20, 25]; // Vendas ao longo das semanas do mês
const ctx = document.getElementById('salesChart').getContext('2d');
const salesChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: ['Semana 1', 'Semana 2', 'Semana 3', 'Semana 4', 'Semana 5'],
        datasets: [{
            label: 'Vendas',
            data: salesData,
            borderColor: 'rgba(75, 192, 192, 1)',
            backgroundColor: 'rgba(75, 192, 192, 0.2)',
            borderWidth: 2,
            fill: true
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                display: true,
            },
            tooltip: {
                enabled: true
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                title: {
                    display: true,
                    text: 'Número de Vendas'
                }
            },
            x: {
                title: {
                    display: true,
                    text: 'Semanas'
                }
            }
        }
    }
});
