// Exemplo de dados dinâmicos
const totalPoints = 1200; // Pontos atuais
const nextRankPoints = 2000; // Meta para o próximo rank

// Atualizar barra de progresso
function updateProgress() {
    const progressElement = document.querySelector('.progress');
    const progressPercentage = (totalPoints / nextRankPoints) * 100;
    
    progressElement.style.width = progressPercentage + '%';
    progressElement.textContent = `${totalPoints} pontos / ${nextRankPoints} pontos`;
    
    const remainingPoints = nextRankPoints - totalPoints;
    document.querySelector('.progress-container p').textContent = `Faltam ${remainingPoints} pontos para atingir o próximo rank.`;
}

// Chamar a função ao carregar a página
window.onload = updateProgress;
