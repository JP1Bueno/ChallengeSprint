// script.js
document.getElementById("botaoChatBotIA").addEventListener("click", function() {
    window.location.href = "index.html"; // Redireciona para a página Chat Bot IA
});
