// clientes.js

document.getElementById('addClientBtn').addEventListener('click', function() {
    const clientName = prompt("Digite o nome do cliente:");
    const clientEmail = prompt("Digite o email do cliente:");
    const clientPhone = prompt("Digite o telefone do cliente:");

    if (clientName && clientEmail && clientPhone) {
        const tableBody = document.getElementById('clientesTableBody');
        const newRow = document.createElement('tr');

        newRow.innerHTML = `
            <td>${clientName}</td>
            <td>${clientEmail}</td>
            <td>${clientPhone}</td>
            <td>
                <button onclick="editClient(this)">Editar</button>
                <button onclick="deleteClient(this)">Excluir</button>
            </td>
        `;
        tableBody.appendChild(newRow);
    }
});

function editClient(button) {
    const row = button.parentElement.parentElement;
    const name = prompt("Editar nome:", row.cells[0].innerText);
    const email = prompt("Editar email:", row.cells[1].innerText);
    const phone = prompt("Editar telefone:", row.cells[2].innerText);

    if (name && email && phone) {
        row.cells[0].innerText = name;
        row.cells[1].innerText = email;
        row.cells[2].innerText = phone;
    }
}

function deleteClient(button) {
    const row = button.parentElement.parentElement;
    row.parentElement.removeChild(row);
}
